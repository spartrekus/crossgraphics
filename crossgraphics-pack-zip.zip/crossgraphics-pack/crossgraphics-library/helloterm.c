

#include <curses.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{	
 	initscr();			
  start_color();
  init_pair(0,  COLOR_WHITE,     COLOR_BLACK);
  init_pair(1,  COLOR_RED,     COLOR_BLACK);
  init_pair(2,  COLOR_GREEN,   COLOR_BLACK);

  printw("Hello World !!!");
  color_set( 2, NULL );
 	mvprintw( 8, 8, "Color Hello World !!!");
 	refresh();		
	 getch();	

	endwin();
	return 0;
}



