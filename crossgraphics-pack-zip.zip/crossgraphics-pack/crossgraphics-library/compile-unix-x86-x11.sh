
# apt-get install xlib-dev gcc

        gcc -L/usr/X11R6/lib -lX11 -o testx11   hellox11.c


