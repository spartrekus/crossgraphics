
=====================================
README CROSSGRAPHICS 
=====================================

- The first idea of crossgraphics is to mimic the GRAPHVGA.H and GRAPHICS.H of BORLAND

- The second important part of the dev is to have a slightest amount of dependencies.
  Only the most default single lib: gdi32 on windows and only x11 on unix/linux!

- It should work on any platforms Android, Atari, Amiga, Unix, BSD, LINUX, and Windows using the GDI32
  It should replicate a screen display which does not rely anything, and that could adapt to the graphics or terminal.

- No need of complicated commands. It justs uses commands such as vga ones, rectangles(), ...
  check graphvga.h
  
- It will not replace QT, SDL,... but gives opportunity to have VGA GRAPHICS on any single platform with the same easy code of VGA-Graphics/graphics.h! 

  
Join the dev at early stages.



  
