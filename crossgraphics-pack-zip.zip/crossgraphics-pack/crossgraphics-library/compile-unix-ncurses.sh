


   gcc -o testunixcurses    -lncurses -lm  helloterm.c




