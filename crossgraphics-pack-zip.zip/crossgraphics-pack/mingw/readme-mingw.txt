

Needs curses.h into include for ncurses
here copy all the files of the compiler gcc into this directory 
here it shall be into this given folder mingw/*: 

bin
doc
include
lib
libexec
mingw32
mingw-autoupdate.cmd
mingw-shell.cmd
Other
share
var




